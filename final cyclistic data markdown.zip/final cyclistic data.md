# Importing the necessary libraries

inspired by the work of joseph stephenson and lewis lee


```python
import pandas as pd
from pandas.api.types import CategoricalDtype

import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
import numpy as np



```


<script type="text/javascript">
window.PlotlyConfig = {MathJaxConfig: 'local'};
if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}
if (typeof require !== 'undefined') {
require.undef("plotly");
requirejs.config({
    paths: {
        'plotly': ['https://cdn.plot.ly/plotly-2.12.1.min']
    }
});
require(['plotly'], function(Plotly) {
    window._Plotly = Plotly;
});
}
</script>



# Importing the datasets


```python
import pandas as pd
df1 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_jan_2022.csv',parse_dates=['started_at','ended_at'])
df2= pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_feb_2022.csv',parse_dates=['started_at','ended_at'])
df3 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_march_2022.csv',parse_dates=['started_at','ended_at']) 
df4 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_april_2022.csv',parse_dates=['started_at','ended_at'])
df5 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_may_2022.csv',parse_dates=['started_at','ended_at'])   
df6 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_june_2022.csv',parse_dates=['started_at','ended_at'])
df7 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_july_2022.csv',parse_dates=['started_at','ended_at'])
df8= pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_august_2022.csv',parse_dates=['started_at','ended_at'])
df9 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_september_2022.csv',parse_dates=['started_at','ended_at']) 
df10 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_october_2022.csv',parse_dates=['started_at','ended_at'])
df11 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_november_2022.csv',parse_dates=['started_at','ended_at'])   
df12 = pd.read_csv('C:\\Users\\arora\\OneDrive\\Desktop\\cyclistic files\\cyclistic_data_december_2022.csv',parse_dates=['started_at','ended_at'])
```

# Combining all the data into a single dataset


```python
df=pd.concat([df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12],ignore_index=True)
df


```

# Exploring the dataset


```python
df.shape
```




    (5667717, 13)




```python
df.info(memory_usage='deep')
#1.5 GB dataframe
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 5667717 entries, 0 to 5667716
    Data columns (total 13 columns):
     #   Column              Dtype         
    ---  ------              -----         
     0   ride_id             object        
     1   rideable_type       object        
     2   started_at          datetime64[ns]
     3   ended_at            datetime64[ns]
     4   start_station_name  object        
     5   start_station_id    object        
     6   end_station_name    object        
     7   end_station_id      object        
     8   start_lat           object        
     9   start_lng           float64       
     10  end_lat             object        
     11  end_lng             float64       
     12  member_casual       object        
    dtypes: datetime64[ns](2), float64(2), object(9)
    memory usage: 3.0 GB
    


```python
df.dtypes
#the columns-'started_at' and 'ended_at' column has been already converted to pandas'  'datetime64' format, to work with.
```




    ride_id                       object
    rideable_type                 object
    started_at            datetime64[ns]
    ended_at              datetime64[ns]
    start_station_name            object
    start_station_id              object
    end_station_name              object
    end_station_id                object
    start_lat                     object
    start_lng                    float64
    end_lat                       object
    end_lng                      float64
    member_casual                 object
    dtype: object




```python
df.columns
```




    Index(['ride_id', 'rideable_type', 'started_at', 'ended_at',
           'start_station_name', 'start_station_id', 'end_station_name',
           'end_station_id', 'start_lat', 'start_lng', 'end_lat', 'end_lng',
           'member_casual'],
          dtype='object')



# Cleaning the Dataset


```python
#now , we will drop the columns which are not relevant to the analysis
df=df.drop(columns=['start_station_name', 'start_station_id', 'end_station_name',
       'end_station_id', 'start_lat', 'start_lng', 'end_lat', 'end_lng'])
```


```python
df
# we have only the relevant columns left now.
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ride_id</th>
      <th>rideable_type</th>
      <th>started_at</th>
      <th>ended_at</th>
      <th>member_casual</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>C2F7DD78E82EC875</td>
      <td>electric_bike</td>
      <td>2022-01-13 11:59:00</td>
      <td>2022-01-13 00:00:00</td>
      <td>casual</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A6CF8980A652D272</td>
      <td>electric_bike</td>
      <td>2022-01-10 08:41:00</td>
      <td>2022-01-10 00:00:00</td>
      <td>casual</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BD0F91DFF741C66D</td>
      <td>classic_bike</td>
      <td>2022-01-25 04:53:00</td>
      <td>2022-01-25 00:00:00</td>
      <td>member</td>
    </tr>
    <tr>
      <th>3</th>
      <td>CBB80ED419105406</td>
      <td>classic_bike</td>
      <td>2022-01-04 00:18:00</td>
      <td>2022-01-04 00:00:00</td>
      <td>casual</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DDC963BFDDA51EEA</td>
      <td>classic_bike</td>
      <td>2022-01-20 01:31:00</td>
      <td>2022-01-20 00:00:00</td>
      <td>member</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>5667712</th>
      <td>43ABEE85B6E15DCA</td>
      <td>classic_bike</td>
      <td>2022-12-05 06:51:00</td>
      <td>2022-12-05 06:54:00</td>
      <td>member</td>
    </tr>
    <tr>
      <th>5667713</th>
      <td>F041C89A3D1F0270</td>
      <td>electric_bike</td>
      <td>2022-12-14 17:06:00</td>
      <td>2022-12-14 17:19:00</td>
      <td>member</td>
    </tr>
    <tr>
      <th>5667714</th>
      <td>A2BECB88430BE156</td>
      <td>classic_bike</td>
      <td>2022-12-08 16:27:00</td>
      <td>2022-12-08 16:32:00</td>
      <td>member</td>
    </tr>
    <tr>
      <th>5667715</th>
      <td>37B392960E566F58</td>
      <td>classic_bike</td>
      <td>2022-12-28 09:37:00</td>
      <td>2022-12-28 09:41:00</td>
      <td>member</td>
    </tr>
    <tr>
      <th>5667716</th>
      <td>2DD1587210BA45AE</td>
      <td>classic_bike</td>
      <td>2022-12-09 00:27:00</td>
      <td>2022-12-09 00:35:00</td>
      <td>casual</td>
    </tr>
  </tbody>
</table>
<p>5667717 rows × 5 columns</p>
</div>




```python
#we will create a column called 'ride_length' which contains the duration between start time and end time
df['ride_length']=(df['ended_at']-df['started_at'])/pd.Timedelta(minutes=1)

df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ride_id</th>
      <th>rideable_type</th>
      <th>started_at</th>
      <th>ended_at</th>
      <th>member_casual</th>
      <th>ride_length</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>C2F7DD78E82EC875</td>
      <td>electric_bike</td>
      <td>2022-01-13 11:59:00</td>
      <td>2022-01-13 00:00:00</td>
      <td>casual</td>
      <td>-719.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A6CF8980A652D272</td>
      <td>electric_bike</td>
      <td>2022-01-10 08:41:00</td>
      <td>2022-01-10 00:00:00</td>
      <td>casual</td>
      <td>-521.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BD0F91DFF741C66D</td>
      <td>classic_bike</td>
      <td>2022-01-25 04:53:00</td>
      <td>2022-01-25 00:00:00</td>
      <td>member</td>
      <td>-293.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>CBB80ED419105406</td>
      <td>classic_bike</td>
      <td>2022-01-04 00:18:00</td>
      <td>2022-01-04 00:00:00</td>
      <td>casual</td>
      <td>-18.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DDC963BFDDA51EEA</td>
      <td>classic_bike</td>
      <td>2022-01-20 01:31:00</td>
      <td>2022-01-20 00:00:00</td>
      <td>member</td>
      <td>-91.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>5667712</th>
      <td>43ABEE85B6E15DCA</td>
      <td>classic_bike</td>
      <td>2022-12-05 06:51:00</td>
      <td>2022-12-05 06:54:00</td>
      <td>member</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>5667713</th>
      <td>F041C89A3D1F0270</td>
      <td>electric_bike</td>
      <td>2022-12-14 17:06:00</td>
      <td>2022-12-14 17:19:00</td>
      <td>member</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>5667714</th>
      <td>A2BECB88430BE156</td>
      <td>classic_bike</td>
      <td>2022-12-08 16:27:00</td>
      <td>2022-12-08 16:32:00</td>
      <td>member</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>5667715</th>
      <td>37B392960E566F58</td>
      <td>classic_bike</td>
      <td>2022-12-28 09:37:00</td>
      <td>2022-12-28 09:41:00</td>
      <td>member</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>5667716</th>
      <td>2DD1587210BA45AE</td>
      <td>classic_bike</td>
      <td>2022-12-09 00:27:00</td>
      <td>2022-12-09 00:35:00</td>
      <td>casual</td>
      <td>8.0</td>
    </tr>
  </tbody>
</table>
<p>5667717 rows × 6 columns</p>
</div>




```python
#we can see some negative values in the column 'ride_length' which means that the end timing is 
# less than the start timing and also , some values are 0 ,which is logically inaccurate. so, let's drop them.


neg_row= df[df['ride_length']<1].index
# shows the index of all such negative value rows
```


```python
#to drop them
df=df.drop(neg_row)

#drops all values less than 1
```


```python
df=df.reset_index().drop(columns='index')                      #resettig the index and dropping the index of the old dataframe 
```


```python
#now , the dataframe containing the values less than 1 is empty , this means all irrelevant values have been dropped.
df[df['ride_length']<1]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ride_id</th>
      <th>rideable_type</th>
      <th>started_at</th>
      <th>ended_at</th>
      <th>member_casual</th>
      <th>ride_length</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
#let's check how many rows we are left with !
df.shape

# there are around 21 lakh rows left out of around 22 lakh rows earlier , approximately , 5.67% of rows are deleted .
```




    (5494220, 6)




```python
# now , let's check for any null or duplicate values
df.isnull().sum().sum()
```




    0




```python
df.duplicated().sum()

#there are no null and duplicate values .

```




    0



# now , let's add some more relevant columns before we begin our analysis

# preparing for analysis


```python
#adding the year column
df['year']=df['started_at'].dt.year

#adding the month_name column
df['day_of_Week']=df['started_at'].dt.day_name()
```


```python
#adding the month column
df['month']=df['ended_at'].dt.month_name()

#adding the hour column
df['hour']=df['started_at'].dt.hour
```


```python
#pd.set_option('display.max_rows',None)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ride_id</th>
      <th>rideable_type</th>
      <th>started_at</th>
      <th>ended_at</th>
      <th>member_casual</th>
      <th>ride_length</th>
      <th>year</th>
      <th>day_of_Week</th>
      <th>month</th>
      <th>hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>8218657C30B87519</td>
      <td>classic_bike</td>
      <td>2022-01-20 23:59:00</td>
      <td>2022-01-21 00:00:00</td>
      <td>member</td>
      <td>1.0</td>
      <td>2022</td>
      <td>Thursday</td>
      <td>January</td>
      <td>23</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2474D16749607644</td>
      <td>classic_bike</td>
      <td>2022-01-09 23:52:00</td>
      <td>2022-01-10 00:00:00</td>
      <td>casual</td>
      <td>8.0</td>
      <td>2022</td>
      <td>Sunday</td>
      <td>January</td>
      <td>23</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BFED8B1B843FD435</td>
      <td>classic_bike</td>
      <td>2022-01-18 23:52:00</td>
      <td>2022-01-19 00:00:00</td>
      <td>casual</td>
      <td>8.0</td>
      <td>2022</td>
      <td>Tuesday</td>
      <td>January</td>
      <td>23</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A498B2E518BD5473</td>
      <td>classic_bike</td>
      <td>2022-01-15 20:49:00</td>
      <td>2022-01-16 00:00:00</td>
      <td>member</td>
      <td>191.0</td>
      <td>2022</td>
      <td>Saturday</td>
      <td>January</td>
      <td>20</td>
    </tr>
    <tr>
      <th>4</th>
      <td>EC181728FD080F2D</td>
      <td>classic_bike</td>
      <td>2022-01-21 23:58:00</td>
      <td>2022-01-22 00:00:00</td>
      <td>casual</td>
      <td>2.0</td>
      <td>2022</td>
      <td>Friday</td>
      <td>January</td>
      <td>23</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>5494215</th>
      <td>43ABEE85B6E15DCA</td>
      <td>classic_bike</td>
      <td>2022-12-05 06:51:00</td>
      <td>2022-12-05 06:54:00</td>
      <td>member</td>
      <td>3.0</td>
      <td>2022</td>
      <td>Monday</td>
      <td>December</td>
      <td>6</td>
    </tr>
    <tr>
      <th>5494216</th>
      <td>F041C89A3D1F0270</td>
      <td>electric_bike</td>
      <td>2022-12-14 17:06:00</td>
      <td>2022-12-14 17:19:00</td>
      <td>member</td>
      <td>13.0</td>
      <td>2022</td>
      <td>Wednesday</td>
      <td>December</td>
      <td>17</td>
    </tr>
    <tr>
      <th>5494217</th>
      <td>A2BECB88430BE156</td>
      <td>classic_bike</td>
      <td>2022-12-08 16:27:00</td>
      <td>2022-12-08 16:32:00</td>
      <td>member</td>
      <td>5.0</td>
      <td>2022</td>
      <td>Thursday</td>
      <td>December</td>
      <td>16</td>
    </tr>
    <tr>
      <th>5494218</th>
      <td>37B392960E566F58</td>
      <td>classic_bike</td>
      <td>2022-12-28 09:37:00</td>
      <td>2022-12-28 09:41:00</td>
      <td>member</td>
      <td>4.0</td>
      <td>2022</td>
      <td>Wednesday</td>
      <td>December</td>
      <td>9</td>
    </tr>
    <tr>
      <th>5494219</th>
      <td>2DD1587210BA45AE</td>
      <td>classic_bike</td>
      <td>2022-12-09 00:27:00</td>
      <td>2022-12-09 00:35:00</td>
      <td>casual</td>
      <td>8.0</td>
      <td>2022</td>
      <td>Friday</td>
      <td>December</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5494220 rows × 10 columns</p>
</div>



# Analysis of Data


```python
#most popular day of week to cycle
df.groupby("member_casual")['day_of_Week'].describe()

#saturday is the most popular day of week for both members and casuals.
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>unique</th>
      <th>top</th>
      <th>freq</th>
    </tr>
    <tr>
      <th>member_casual</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>casual</th>
      <td>2276038</td>
      <td>7</td>
      <td>Saturday</td>
      <td>463736</td>
    </tr>
    <tr>
      <th>member</th>
      <td>3218182</td>
      <td>7</td>
      <td>Thursday</td>
      <td>511695</td>
    </tr>
  </tbody>
</table>
</div>




```python
#most popular month to cycle
df.groupby("member_casual")['month'].describe()

# june is the most popular month for both members and casuals.
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>unique</th>
      <th>top</th>
      <th>freq</th>
    </tr>
    <tr>
      <th>member_casual</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>casual</th>
      <td>2276038</td>
      <td>12</td>
      <td>July</td>
      <td>401320</td>
    </tr>
    <tr>
      <th>member</th>
      <td>3218182</td>
      <td>12</td>
      <td>August</td>
      <td>421309</td>
    </tr>
  </tbody>
</table>
</div>




```python
# average ride_length for members and casual riders by day of week
order_of_days=['Monday', 'Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']

avg_ride_length =df.groupby(['member_casual','day_of_Week'])['ride_length'].mean()

#setting the correct order
pd.DataFrame(avg_ride_length).reindex(index=order_of_days,level=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>ride_length</th>
    </tr>
    <tr>
      <th>member_casual</th>
      <th>day_of_Week</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="7" valign="top">casual</th>
      <th>Monday</th>
      <td>29.611293</td>
    </tr>
    <tr>
      <th>Tuesday</th>
      <td>26.222880</td>
    </tr>
    <tr>
      <th>Wednesday</th>
      <td>25.092961</td>
    </tr>
    <tr>
      <th>Thursday</th>
      <td>25.909793</td>
    </tr>
    <tr>
      <th>Friday</th>
      <td>28.446520</td>
    </tr>
    <tr>
      <th>Saturday</th>
      <td>33.110567</td>
    </tr>
    <tr>
      <th>Sunday</th>
      <td>34.557943</td>
    </tr>
    <tr>
      <th rowspan="7" valign="top">member</th>
      <th>Monday</th>
      <td>12.458583</td>
    </tr>
    <tr>
      <th>Tuesday</th>
      <td>12.295705</td>
    </tr>
    <tr>
      <th>Wednesday</th>
      <td>12.285217</td>
    </tr>
    <tr>
      <th>Thursday</th>
      <td>12.479301</td>
    </tr>
    <tr>
      <th>Friday</th>
      <td>12.725900</td>
    </tr>
    <tr>
      <th>Saturday</th>
      <td>14.399812</td>
    </tr>
    <tr>
      <th>Sunday</th>
      <td>14.265053</td>
    </tr>
  </tbody>
</table>
</div>




```python
#average ride_length of casuals and members by month.
month_order=['January', 'February', 'March', 'April', 'May', 'June', "July", "August", "September", "October", "November",
             "December"]
avg_ride_length= df.groupby(['member_casual','month'])['ride_length'].mean()

#making it into a dataframe with the correct order of months
#pd.DataFrame(avg_ride_length).reindex(index=month_order)
avg_ride_length.reindex(index=month_order,level=1)

```




    member_casual  month    
    casual         January      1001.698690
                   February       27.106832
                   March          32.701820
                   April          29.566478
                   May            31.065533
                   June           30.046682
                   July           31.343060
                   August         29.627719
                   September      28.006676
                   October        28.020768
                   November       22.973867
                   December       22.238881
    member         January       174.907336
                   February       11.555962
                   March          12.092279
                   April          11.626691
                   May            13.524720
                   June           14.166053
                   July           13.921849
                   August         13.544344
                   September      13.143524
                   October        12.110926
                   November       11.355583
                   December       10.769215
    Name: ride_length, dtype: float64




```python
#no of rides of members and casuals by day_of_week

no_of_rides= df.groupby(['member_casual','day_of_Week'])['ride_id'].count()

#setting the correct order
pd.DataFrame(no_of_rides).reindex(index=order_of_days,level=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>member_casual</th>
      <th>day_of_Week</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="7" valign="top">casual</th>
      <th>Monday</th>
      <td>272038</td>
    </tr>
    <tr>
      <th>Tuesday</th>
      <td>258152</td>
    </tr>
    <tr>
      <th>Wednesday</th>
      <td>268780</td>
    </tr>
    <tr>
      <th>Thursday</th>
      <td>303191</td>
    </tr>
    <tr>
      <th>Friday</th>
      <td>328317</td>
    </tr>
    <tr>
      <th>Saturday</th>
      <td>463736</td>
    </tr>
    <tr>
      <th>Sunday</th>
      <td>381824</td>
    </tr>
    <tr>
      <th rowspan="7" valign="top">member</th>
      <th>Monday</th>
      <td>454153</td>
    </tr>
    <tr>
      <th>Tuesday</th>
      <td>498676</td>
    </tr>
    <tr>
      <th>Wednesday</th>
      <td>504522</td>
    </tr>
    <tr>
      <th>Thursday</th>
      <td>511695</td>
    </tr>
    <tr>
      <th>Friday</th>
      <td>449862</td>
    </tr>
    <tr>
      <th>Saturday</th>
      <td>426265</td>
    </tr>
    <tr>
      <th>Sunday</th>
      <td>373009</td>
    </tr>
  </tbody>
</table>
</div>




```python
#no of rides of members and casuals in each month

no_of_rides= df.groupby(['member_casual','month'])['ride_id'].count()

#setting the correct order
pd.DataFrame(no_of_rides).reindex(index=month_order,level=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>member_casual</th>
      <th>month</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="12" valign="top">casual</th>
      <th>January</th>
      <td>229</td>
    </tr>
    <tr>
      <th>February</th>
      <td>21108</td>
    </tr>
    <tr>
      <th>March</th>
      <td>88933</td>
    </tr>
    <tr>
      <th>April</th>
      <td>124891</td>
    </tr>
    <tr>
      <th>May</th>
      <td>277205</td>
    </tr>
    <tr>
      <th>June</th>
      <td>364787</td>
    </tr>
    <tr>
      <th>July</th>
      <td>401320</td>
    </tr>
    <tr>
      <th>August</th>
      <td>354506</td>
    </tr>
    <tr>
      <th>September</th>
      <td>293136</td>
    </tr>
    <tr>
      <th>October</th>
      <td>206329</td>
    </tr>
    <tr>
      <th>November</th>
      <td>99413</td>
    </tr>
    <tr>
      <th>December</th>
      <td>44181</td>
    </tr>
    <tr>
      <th rowspan="12" valign="top">member</th>
      <th>January</th>
      <td>259</td>
    </tr>
    <tr>
      <th>February</th>
      <td>92839</td>
    </tr>
    <tr>
      <th>March</th>
      <td>191994</td>
    </tr>
    <tr>
      <th>April</th>
      <td>241671</td>
    </tr>
    <tr>
      <th>May</th>
      <td>350162</td>
    </tr>
    <tr>
      <th>June</th>
      <td>395151</td>
    </tr>
    <tr>
      <th>July</th>
      <td>411985</td>
    </tr>
    <tr>
      <th>August</th>
      <td>421309</td>
    </tr>
    <tr>
      <th>September</th>
      <td>399444</td>
    </tr>
    <tr>
      <th>October</th>
      <td>344851</td>
    </tr>
    <tr>
      <th>November</th>
      <td>233833</td>
    </tr>
    <tr>
      <th>December</th>
      <td>134684</td>
    </tr>
  </tbody>
</table>
</div>



# Visualisation of Data


no of rides taken by casual riders and members , by each month


```python
plt.figure(figsize = (11,10))
sns.histplot(x = "month", data = df, hue = 'member_casual', palette = 'Pastel1')
plt.title('Monthly Count of Rides')

#for casual riders,the maximum number of rides are taken in july , wheras for members , it is in august.

# the maximum number of rides are in the month of july and august overall , with the summer season seeing the no of rides peak as
# it approaches , as compared to the winter season (december to february , when no of rides are the least.)
```




    Text(0.5, 1.0, 'Monthly Count of Rides')




    
![png](output_37_1.png)
    



```python

plt.figure(figsize = (10,6))
sns.histplot(x = "day_of_Week", data = df, hue = 'member_casual', palette = 'Pastel1')
plt.title('weekly Count of Rides')

# from the visualisation , we can clearly see that for casual riders , there is a peak in the no of rides on weekends 
# for members , the no of rides taken remain more or less consistent throughout the week , with a slight peak on thursday
```




    Text(0.5, 1.0, 'weekly Count of Rides')




    
![png](output_38_1.png)
    



```python
casual = df.loc[df['member_casual'] == 'casual']
member = df.loc[df['member_casual'] == 'member']


plt.figure(figsize = (10,6))
sns.histplot(x = "day_of_Week", data = casual, hue = 'rideable_type')
plt.title("Casual")

plt.figure(figsize = (10,6))
sns.histplot(x = "day_of_Week", data = member, hue = 'rideable_type')
plt.title("Member")


# here , we can see that the casual riders mostly active of weekends with an electric bike
# the annual riders are the least active on weekends and mostly use a classic bike.
```




    Text(0.5, 1.0, 'Member')




    
![png](output_39_1.png)
    



    
![png](output_39_2.png)
    



```python
hourly_count = df.groupby(['hour','member_casual'])['ride_id'].count()
plt.figure(figsize = (20,10))
sns.histplot(x = 'hour', data = df, hue='member_casual',palette='twilight')

sns.set_style("white")
sns.set_context('paper', font_scale = 3)
# the number of riders peak in the evening hours between 3pm to 7pm , with the highest number of riders at 5pm
```


    
![png](output_40_0.png)
    



```python

```
